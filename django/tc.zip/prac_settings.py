# templates = [
# {
#     'DIRS': [os.path.join(BASE_DIR, '프로젝트명', 'templates')], 
#     # 템플릿 기본 파일 경로 지정 (프로젝트명의 templates폴더)
# }
# ]